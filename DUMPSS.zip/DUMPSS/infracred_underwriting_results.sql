-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: infracred
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `underwriting_results`
--

DROP TABLE IF EXISTS `underwriting_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `underwriting_results` (
  `result_id` int unsigned NOT NULL AUTO_INCREMENT,
  `leads_id` int unsigned DEFAULT NULL,
  `risk_rating` varchar(255) DEFAULT NULL,
  `approved_amount` decimal(15,2) NOT NULL,
  `decision` varchar(255) DEFAULT NULL,
  `underwriter_notes` text,
  `evaluated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `agent_id` int unsigned DEFAULT NULL,
  `rate_of_interest` decimal(5,2) DEFAULT NULL,
  `tenure_months` int DEFAULT NULL,
  PRIMARY KEY (`result_id`),
  KEY `fk_leads_id` (`leads_id`),
  KEY `fk_underwriting_agent` (`agent_id`),
  CONSTRAINT `fk_leads_id` FOREIGN KEY (`leads_id`) REFERENCES `leads` (`leads_id`),
  CONSTRAINT `fk_underwriting_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `underwriting_results`
--

LOCK TABLES `underwriting_results` WRITE;
/*!40000 ALTER TABLE `underwriting_results` DISABLE KEYS */;
INSERT INTO `underwriting_results` VALUES (1,4,'LOW',800000.00,'APPROVED','Loan approved with low risk.','2025-05-10 12:25:11',NULL,NULL,NULL),(2,4,'MEDIUM',800000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-10 13:11:30',NULL,NULL,NULL),(3,6,'HIGH',200000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-12 09:34:02',NULL,NULL,NULL),(4,39,'LOW',9000000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-21 12:40:42',NULL,NULL,NULL),(5,38,'HIGH',600000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-21 12:58:39',NULL,NULL,NULL),(6,34,'LOW',2000000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-21 15:14:14',NULL,NULL,NULL),(7,37,'MEDIUM',400000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-21 15:26:07',NULL,NULL,NULL),(8,40,'MEDIUM',400000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-22 11:16:38',NULL,NULL,NULL),(9,61,'LOW',400000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-23 11:56:01',NULL,NULL,NULL),(10,62,'MEDIUM',400000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-23 12:55:30',NULL,NULL,NULL),(11,64,'LOW',400000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-23 13:25:59',NULL,NULL,NULL),(12,65,'MEDIUM',400000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-23 14:54:17',NULL,NULL,NULL),(13,66,'HIGH',300000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-23 15:10:52',NULL,NULL,NULL),(14,72,'LOW',300000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-26 11:49:03',NULL,NULL,NULL),(15,73,'LOW',40000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-26 15:29:23',NULL,NULL,NULL),(16,74,'HIGH',60000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-26 16:22:43',NULL,NULL,NULL),(17,75,'MEDIUM',30000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-27 11:52:12',NULL,NULL,NULL),(18,76,'HIGH',50000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-27 12:22:43',NULL,NULL,NULL),(19,71,'LOW',400000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-27 12:57:15',NULL,NULL,NULL),(20,70,'LOW',400000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-27 13:29:43',NULL,NULL,NULL),(21,77,'MEDIUM',60000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-27 15:17:06',NULL,NULL,NULL),(22,78,'MEDIUM',500000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-27 15:27:46',NULL,NULL,NULL),(23,79,'LOW',200000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-28 08:34:58',NULL,NULL,NULL),(24,80,'LOW',500000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-28 09:25:17',NULL,NULL,NULL),(25,81,'LOW',600000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-28 10:46:22',NULL,NULL,NULL),(26,82,'LOW',500000.00,'CONDITIONAL','Loan conditionally approved with low creditworthiness.','2025-05-28 12:30:19',NULL,NULL,NULL),(27,68,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-28 14:42:22',3,12.00,36),(28,84,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-28 15:53:45',25,12.00,23),(29,85,'MEDIUM',100000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-28 16:02:58',26,12.00,10),(30,86,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-28 17:01:49',25,12.00,22),(31,87,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-28 17:05:22',26,12.00,12),(32,88,'MEDIUM',200000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-28 17:11:41',18,12.00,10),(33,89,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-28 17:19:47',19,12.00,23),(34,91,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-28 17:27:55',27,12.00,12),(35,92,'HIGH',100000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-29 08:51:46',28,15.00,10),(36,93,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-29 09:10:21',29,15.00,12),(37,94,'MEDIUM',300000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-29 09:18:26',27,15.00,22),(38,95,'HIGH',500000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-29 09:50:34',28,15.00,22),(39,96,'MEDIUM',500000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-29 10:07:45',29,12.00,24),(40,97,'MEDIUM',200000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-29 10:23:21',21,20.00,22),(41,98,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-29 11:07:00',30,20.00,36),(42,99,'MEDIUM',300000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-29 11:12:24',30,25.00,24),(43,100,'MEDIUM',100000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-29 12:43:12',31,12.00,24),(44,101,'MEDIUM',500000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-29 14:31:40',31,12.00,24),(45,102,'MEDIUM',200000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-29 16:03:39',32,15.00,24),(46,128,'HIGH',200000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-30 15:32:52',24,15.00,11),(47,129,'HIGH',300000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-30 16:24:32',25,15.00,22),(48,137,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-31 09:58:18',4,15.00,24),(49,136,'HIGH',200000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-31 10:00:49',3,15.00,24),(50,140,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-31 15:08:02',6,15.00,12),(51,141,'MEDIUM',100000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-05-31 15:14:54',8,15.00,24),(52,143,'LOW',0.00,'REJECTED','Credit score too low.','2025-05-31 16:18:20',11,15.00,24),(53,144,'HIGH',400000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-31 16:28:56',12,15.00,12),(54,145,'HIGH',400000.00,'APPROVED','Loan approved with high creditworthiness.','2025-05-31 16:51:44',13,15.00,24),(55,146,'MEDIUM',200000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-06-02 09:38:36',14,15.00,24),(56,147,'HIGH',400000.00,'APPROVED','Loan approved with high creditworthiness.','2025-06-02 12:13:56',15,12.00,24),(57,148,'MEDIUM',300000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-06-02 15:59:52',16,12.00,24),(58,150,'MEDIUM',200000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-06-03 09:21:16',18,15.00,24),(59,151,'HIGH',200000.00,'APPROVED','Loan approved with high creditworthiness.','2025-06-03 09:43:11',19,15.00,24),(60,152,'LOW',0.00,'REJECTED','Credit score too low.','2025-06-03 17:21:36',20,15.00,24),(61,154,'MEDIUM',200000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-06-04 12:24:49',21,15.00,12),(62,157,'MEDIUM',100000.00,'APPROVED','Loan approved with medium creditworthiness.','2025-06-04 15:57:39',36,15.00,12);
/*!40000 ALTER TABLE `underwriting_results` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-06  9:09:06
