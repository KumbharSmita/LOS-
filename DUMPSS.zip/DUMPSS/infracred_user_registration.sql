-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: infracred
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_registration`
--

DROP TABLE IF EXISTS `user_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_registration` (
  `user_registration_id` int unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(45) NOT NULL,
  `contact_no` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`user_registration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_registration`
--

LOCK TABLES `user_registration` WRITE;
/*!40000 ALTER TABLE `user_registration` DISABLE KEYS */;
INSERT INTO `user_registration` VALUES (1,'Narendra Modi','narendra23@gmail.com','narendra123','4567465734'),(2,'Narendra Modi','narendra23@gmail.com','narendra123','4567465734'),(3,'Amit Shah','7465784485','amit23@gmail.com','amit123'),(4,'hjdhfj','3458346845','fdl2@gmail.com','sjshjsh3'),(5,'Nisha Jain','3764375665','nisha123@gmail.com','nisha1234'),(6,'sunanda pawar','2343756433','sunanda12@gmail.com','sunanda123'),(7,'Smita Kumbhar','90672214163','smita12@gmail.com','dassj112'),(8,'Rohini Shewale','2745637422','rohinishewale23@gmail.com','rohini123'),(9,'Smita Kumbhar','9067221416','anushri1725@gmail.com','anushri123'),(10,'Ishan Kishan','8676969888','ishan23@gmail.com','ishan123'),(11,'Aniket Varma','2736746764','aniket1725@gmail.com','84968678'),(12,'Sarthak Shelke','2634843873','sarthak23@gmail.com','sartha234'),(13,'Lata Mangeshkar','3243455564','lata23@gmail.com','lata1234'),(14,'Akash Waje','2463786545','akash3@gmail.com','akash123'),(15,'Pooja Waje','4839594859','pooja12@gmail.com','pooja123'),(16,'Narendra Modi','4657477383','narendra34@gmail.com','narendre123456'),(17,'Suvarna Patil','2387438478','suvarna45@gmail.com','372847363'),(18,'Jitesh Sharma','5497567876','jitesh45@gmail.com','jitesh123'),(19,'Gita Gawade','5748684543','sganjegaonkar07@gmail.com','244535fr4'),(20,'Pratiksha Karde','3785647564','pratiksha23@gmail.com','pratiksha12345'),(21,'sujata jagtap','4395748765','sujata23@gmail.com','sujata345'),(22,'Vaishnavi Khaire','3438975465','vaishnavi@gmail.com','hcfdjddfd'),(23,'Pratiksha Joshi','4857686867','pratiksha345@gmail.com','048594768g'),(24,'Neha jagtap','7436756884','neha2@gmail.com','jdfksjlk'),(25,'Rushikesh Jagdale','3975487585','sh373437@gmail.com','48783758'),(26,'Lokesh Patil','7676765455','lokesh2@gmail.com','dfjkldsr'),(27,'Amruta Khaladkar','4354676776','amruta45@gmail.com','768uyhtyt'),(28,'Anil Shelke','8476875857','anil12@gmail.com','sjdsklslddf'),(29,'Anjali Mehata','4564656767','anjali3312@gmail.com','anjali87y'),(30,'Sonalika Desai','4387548578','sonalika@gmail.com','47r8jfhj'),(31,'Namarat Joshi','2398439585','namarat65@gmail.com','ksjdksjksd'),(32,'Sambhaji Hojage','4574969697','sambhaji65@gmail.com','kjrkeiru837'),(33,'Sayali Darekar','5987689766','sayali8765@gmail.com','87584hdnfj'),(34,'Riya dalal','8568457845','riyal12@gmail.com','gtgerte'),(35,'hemali dabi','3485748966','hemali2@gmail.com','sjdksjds3'),(36,'Siyana Diwan','8454857875','siyana78@gmail.com','sdksdsoow'),(37,'Shaurya Diwan','4957487687','shaurya78@gmail.com','hthtffgf'),(38,'Sahil Jadhav','3454666756','sahil3@gmail.com','djdffdkf'),(39,'Nikita Jadhav','3864365678','nikkita3@gmail.com','dsfjdjdwe'),(40,'nita ','4545445434','nita3@gmail.com','gfdgdedfs'),(41,'Tukaram Munde','7657647654','tukaram44@gmail.com','dferfer'),(42,'Nilam Gorhe','4976895768','nilam34@gmail.com','ksdjkjfe'),(43,'Payal Dabi','3784567465','payal34@gmail.com','6767ghgbh'),(44,'Rashmi Shukla','4876547866','rashmi734@gmail.com','kdljedj'),(45,'Swapnali Shinde','4967598697','swapnali734@gmail.com','gfrgfgfg'),(46,'Apala Mishra','4876876856','apala734@gmail.com','03849745'),(47,'Seema Gunjal','3957478685','seema734@gmail.com','4059048596'),(48,'Sidharth Shelke','4837548766','sh734@gmail.com','sdfsfdgfdg'),(49,'Kalpana Mishra','4836576599','kalpana12@gmail.com','ksdjfkjfkd'),(50,'Ankita Lokhnade','3489574875','ankita54@gmail.com','lskdlfksj'),(51,'Sujata Lokhande','3947835745','suj23@gmail.com','dkfldkff'),(52,'Atul Shelke','3497875487','atul23@gmail.com','4564trf'),(53,'Amol Shelke','8465478567','amoi9823@gmail.com','dsfdfdf'),(54,'Gauri Kute','4976876655','gauri9823@gmail.com','djfieufr'),(55,'Sejal Sharma','3975457847','sejal823@gmail.com','dfkdlfd'),(56,'Pratiksha Katore','4857487655','prtikshaa823@gmail.com','fggrdfer'),(57,'Tanvi Bhukan','4857484787','tanvi823@gmail.com','eljkrelfreo'),(58,'Surabhi Pandit','3435434434','surbhi23@gmail.com','refdfgftg'),(59,'Bhagyashri Joshi','3897483587','bhagyashri23@gmail.com','fgfgfgrfgg'),(60,'Poonam Jagtap','4975847686','poonam23@gmail.com','wjdskjdks'),(61,'Priya Shelke','3957487585','priya23@gmail.com','erjdkjksdj'),(62,'Pratikasha Pawar','3453545656','pratiksha65@gmail.com','dsjksdsd'),(63,'Shivani Badhe','4358748577','shivani65@gmail.com','whjkwdiweu'),(64,'Nisha Jagtap','3485647865','nisha23@gmail.com','dfdsfdfs'),(65,'Divya k','4574574878','smitakumbhar.imperative@gmail.com','3487357gf'),(66,'Yashwavi Jaiswal','3958457685','yashswi455@gmail.com','gfhtgfhtf'),(67,'Rutuja Markad','3298549594','rutuja455@gmail.com','wkdlsdosi'),(68,'Arpita Shinde','3438549776','arpita32@gmail.com','24038jkor'),(69,'Vanita Shinde','3333333354','vanita32@gmail.com','sldklsk'),(70,'Aasha Shirke','4546546765','asha332@gmail.com','jhui7hj'),(71,'Snehal Bansode','3248758477','snehal982@gmail.com','fgdferfe'),(72,'Atharav Dhaybar','3486548648','atharva@gmail.com','odfjodsjf'),(73,'Rasika Shinde','3445467765','rasika34@gmail.com','dsfhjkf'),(74,'Lokesh ','8375847585','lokeshtpatil@gmail.com','65654646'),(75,'Radha Yadav','4876876876','radha4@gmail.com','djskjdkjr'),(76,'Savita Mukhekar','3784637846','savita34@gmail.com','4564656t'),(77,'Anish Varma','4857485456','anish34@gmail.com','kdjfdktj'),(78,'Mitali Thakare','3485748757','mitali34@gmail.com','jhfjhfruyr'),(79,'Raj Thakare','3854654766','raj43@gmail.com','kjfkdjfkdjk'),(80,'Udhav Thakare','2457686787','udhav33@gmail.com','sdkjfjkf'),(81,'Savita Shinde','3434535475','savita67@gmail.com','dfrer4r34'),(82,'Pratiksha Karde','3874865778','kardepratiksha890@gmail.com','dfhjdjfk'),(83,'Shraddha Bhujabal','3456478754','bhujabal890@gmail.com','ghghgyht'),(84,'Sanjana Singh','5466576766','singh890@gmail.com','ghghgfhyty'),(85,'Spruha Joshi','4568998989','spruhajoshi34@gmail.com','dkfjdknfhdj4'),(86,'Samiksha Joshi','3586965685','samiksha34@gmail.com','gyfgty576'),(87,'Arpita Joshi','3478787878','arpita34@gmail.com','dkfjkdjf'),(88,'Nikita Shelke','4758477574','nikita34@gmail.com','dfjiorui9e'),(89,'Vaibhav Sonawane','3475645454','vaibhav@gmail.com','sjdhjeyrhyje'),(90,'Nita Ambani','4786578767','nita56@gmail.com','dfkdjgdkj'),(91,'Mukesh Ambani','4978689579','mukesh@gmail.com','ehsfdjfh4'),(92,'Radhika Merchant','4364565665','radhika2@gmail.com','sdfjkjfd'),(93,'Akash Ambani','9347658658','akash87@gmail.com','sdhsjkhdjs'),(94,'Shloka Ambani','4387876885','shloka3@gmail.com','gghdfgrfd');
/*!40000 ALTER TABLE `user_registration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-06  9:09:05
