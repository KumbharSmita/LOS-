-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: infracred
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agent_registration`
--

DROP TABLE IF EXISTS `agent_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_registration` (
  `agent_registration_id` int unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(45) NOT NULL,
  `contactno` varchar(20) NOT NULL,
  `office_location` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `role` enum('ADMIN','SUPER_ADMIN') DEFAULT NULL,
  PRIMARY KEY (`agent_registration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_registration`
--

LOCK TABLES `agent_registration` WRITE;
/*!40000 ALTER TABLE `agent_registration` DISABLE KEYS */;
INSERT INTO `agent_registration` VALUES (1,'Akanksha S Waje','wajeakanksha@gmail.com','123456789','1234567890','Wajewadi','active','ADMIN'),(2,'Tanuja H Shelke','tanujashelke@gmail.com','tanuja812','9876543211','Ranjangaon','active','ADMIN'),(3,'Nisha','nisha@gmail.com','12345678','1234567895','Pune','active','ADMIN'),(4,'Nisha','nisha@gmail.com','12345678','1234567895','Pune','active','ADMIN'),(5,'Disha','disha@gmail.com','82345678','174567895','Pune','active','ADMIN'),(6,'Shakti Dube','shakti@gmail.com','98999796','8888111213','pune','active','ADMIN'),(7,'ria dabi','riya@gmail.com','77777777','9999999999','pune','active','ADMIN'),(8,'siya dabi','siya@gmail.com','66666666','5555555555','pune','active','ADMIN'),(9,'rutu dabi','rutu@gmail.com','11111111','11111111111','pune','active','ADMIN'),(10,'rutu dabi','123@gmail.com','11111111','11111111111','pune','active','ADMIN'),(11,'Akanksha S Waje','wajeakanksha1@gmail.com','123456789','1234567890','Wajewadi','active','ADMIN'),(12,'Sanu S Waje','sanu@gmail.com','99999999','7878787878','Wajewadi','active','ADMIN'),(13,'Anjali','anjali@gmail.com','77755545','7575757575','pune','active','ADMIN'),(14,'anisha','anisha@gmail.com','anisha123','2123131221','pune','active','ADMIN'),(15,'manisha ','manisha12@gmail.com','1211332323','2718483655','pune','active','ADMIN'),(16,'rfjvgkdnk','dfcksj@gmail.com','37657836538','3756376535','pune','active','ADMIN'),(17,'hrkgjkr','dfdfl12@gmail.com','dcfdsfcl1213','3243546234','pune','active','ADMIN'),(18,'rhydgfd','gfdfg23@gmail.com','1235435','2345356455','pune','active','ADMIN'),(19,'  Narendra dabi','dabi12@gmail.com','4375638783','3435754758','pune','active','SUPER_ADMIN'),(20,'  Devendra Fadnvis','fadnvis12@gmail.com','3478637','3748738533','Nagpur','active','SUPER_ADMIN'),(21,'Yogi Adityanath','yogi123@gmail.com','yogi1234','3247356437','Uttarpradesh','Active','ADMIN'),(22,'Pankaja Munde','pankaja23@gmail.com','pankaja123','1234546756','pune','active','ADMIN'),(23,' Rakshs Khadse','raksha12@gmail.com','raksha1234','8765843758','Jalgaon','active','ADMIN'),(24,'Aditi tatkare','aditi122@gmail.com','aditi1234','4538373377','Raigad','active','ADMIN'),(25,'Amol Kolhe','amol123@gmail.com','amol1234','4375834743','Shirur','Active','SUPER_ADMIN'),(26,'Chagan Bhujabal','chagan12@gmail.com','chagan1234','2348653489','pune','Active','SUPER_ADMIN'),(27,'Isha Ambani','isha12@gmail.com','isha1234','3243567676','pune','active','ADMIN'),(28,'hanumant jagtap','hanumant455@gmail.com','8364375647','3864356478','pune','active','ADMIN'),(29,'Simran Dabi','simran34@gmail.com','dsjkhsdff','3456789909','pune','active','ADMIN'),(30,'Sharada Pawar','sharada12@gmail.com','adklasjdsjfk','4957487685','pune','active','ADMIN'),(31,'Tarak Mehata','tarak12@gmail.com','tarak8238','3243434323','wagholi','active','ADMIN'),(32,'Madhavi Desai','madhavi2@gmail.com','akdlwdlfef','6544345645','pune','active','ADMIN'),(33,'Tina Dalal','dalal12@gmail.com','7845hedfk','4578477565','Shirur','Active','ADMIN'),(34,'Natasha Daalal','natasha2@gmail.com','ureiofejf','4875487547','Shirur','Active','ADMIN'),(35,'Tanushaka Jadhav','tanushka4@gmail.com','djkskljf','5465656655','wagholi','Active','ADMIN'),(36,'Swastik Chikara','swastik4@gmail.com','fhejhirt','4365478545','Shirur','Active','ADMIN'),(37,'Alpana Mishra','alpana12@gmail.com','fgrgtrtr','2343546566','Uttarpradesh','Active','ADMIN'),(38,'Rupa Bora','rupa12@gmail.com','dkjfskjd','3434343435','wagholi','active','ADMIN'),(39,'Anant Ambani','anant@gmail.com','hedfjehf','3846766756','Shirur','Active','ADMIN');
/*!40000 ALTER TABLE `agent_registration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-06  9:09:06
