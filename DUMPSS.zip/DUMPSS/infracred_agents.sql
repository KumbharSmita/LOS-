-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: infracred
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agents`
--

DROP TABLE IF EXISTS `agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agents` (
  `agent_id` int unsigned NOT NULL AUTO_INCREMENT,
  `agent_registration_id` int unsigned DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contactno` varchar(20) NOT NULL,
  `office_location` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `role` enum('ADMIN','SUPER_ADMIN') DEFAULT NULL,
  PRIMARY KEY (`agent_id`),
  UNIQUE KEY `email` (`email`),
  KEY `agent_registration_id` (`agent_registration_id`),
  CONSTRAINT `agents_ibfk_1` FOREIGN KEY (`agent_registration_id`) REFERENCES `agent_registration` (`agent_registration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agents`
--

LOCK TABLES `agents` WRITE;
/*!40000 ALTER TABLE `agents` DISABLE KEYS */;
INSERT INTO `agents` VALUES (1,3,'Nisha','nisha@gmail.com','1234567895','Pune','active','ADMIN'),(3,5,'Disha','disha@gmail.com','174567895','Pune','active','ADMIN'),(4,6,'Shakti Dube','shakti@gmail.com','8888111213','pune','active','ADMIN'),(5,7,'ria dabi','riya@gmail.com','9999999999','pune','active','ADMIN'),(6,8,'siya dabi','siya@gmail.com','5555555555','pune','active','ADMIN'),(7,9,'rutu dabi','rutu@gmail.com','11111111111','pune','active','ADMIN'),(8,10,'rutu dabi','123@gmail.com','11111111111','pune','active','ADMIN'),(9,11,'Akanksha S Waje','wajeakanksha1@gmail.com','1234567890','Wajewadi','active','ADMIN'),(10,12,'Sanu S Waje','sanu@gmail.com','7878787878','Wajewadi','active','ADMIN'),(11,13,'Anjali','anjali@gmail.com','7575757575','pune','active','ADMIN'),(12,14,'anisha','anisha@gmail.com','2123131221','pune','active','ADMIN'),(13,15,'manisha ','manisha12@gmail.com','2718483655','pune','active','ADMIN'),(14,16,'rfjvgkdnk','dfcksj@gmail.com','3756376535','pune','active','ADMIN'),(15,17,'hrkgjkr','dfdfl12@gmail.com','3243546234','pune','active','ADMIN'),(16,18,'rhydgfd','gfdfg23@gmail.com','2345356455','pune','active','ADMIN'),(17,20,'  Devendra Fadnvis','fadnvis12@gmail.com','3748738533','Nagpur','active','SUPER_ADMIN'),(18,21,'Yogi Adityanath','yogi123@gmail.com','3247356437','Uttarpradesh','Active','ADMIN'),(19,22,'Pankaja Munde','pankaja23@gmail.com','1234546756','pune','active','ADMIN'),(20,23,' Rakshs Khadse','raksha12@gmail.com','8765843758','Jalgaon','active','ADMIN'),(21,24,'Aditi tatkare','aditi122@gmail.com','4538373377','Raigad','active','ADMIN'),(22,25,'Amol Kolhe','amol123@gmail.com','4375834743','Shirur','Active','SUPER_ADMIN'),(23,26,'Chagan Bhujabal','chagan12@gmail.com','2348653489','pune','Active','SUPER_ADMIN'),(24,27,'Isha Ambani','isha12@gmail.com','3243567676','pune','active','ADMIN'),(25,28,'hanumant jagtap','hanumant455@gmail.com','3864356478','pune','active','ADMIN'),(26,29,'Simran Dabi','simran34@gmail.com','3456789909','pune','active','ADMIN'),(27,30,'Sharada Pawar','sharada12@gmail.com','4957487685','pune','active','ADMIN'),(28,31,'Tarak Mehata','tarak12@gmail.com','3243434323','wagholi','active','ADMIN'),(29,32,'Madhavi Desai','madhavi2@gmail.com','6544345645','pune','active','ADMIN'),(30,33,'Tina Dalal','dalal12@gmail.com','4578477565','Shirur','Active','ADMIN'),(31,34,'Natasha Daalal','natasha2@gmail.com','4875487547','Shirur','Active','ADMIN'),(32,35,'Tanushaka Jadhav','tanushka4@gmail.com','5465656655','wagholi','Active','ADMIN'),(33,36,'Swastik Chikara','swastik4@gmail.com','4365478545','Shirur','Active','ADMIN'),(34,37,'Alpana Mishra','alpana12@gmail.com','2343546566','Uttarpradesh','Active','ADMIN'),(35,38,'Rupa Bora','rupa12@gmail.com','3434343435','wagholi','active','ADMIN'),(36,39,'Anant Ambani','anant@gmail.com','3846766756','Shirur','Active','ADMIN');
/*!40000 ALTER TABLE `agents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-06  9:09:07
