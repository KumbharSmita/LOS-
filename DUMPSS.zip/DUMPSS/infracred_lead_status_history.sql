-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: infracred
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lead_status_history`
--

DROP TABLE IF EXISTS `lead_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_status_history` (
  `history_id` int unsigned NOT NULL AUTO_INCREMENT,
  `leads_id` int unsigned DEFAULT NULL,
  `agent_id` int unsigned DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`history_id`),
  KEY `leads_id` (`leads_id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `lead_status_history_ibfk_1` FOREIGN KEY (`leads_id`) REFERENCES `leads` (`leads_id`),
  CONSTRAINT `lead_status_history_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_status_history`
--

LOCK TABLES `lead_status_history` WRITE;
/*!40000 ALTER TABLE `lead_status_history` DISABLE KEYS */;
INSERT INTO `lead_status_history` VALUES (1,26,3,'in progress','2025-04-26 15:48:34'),(2,26,3,'in complete','2025-04-26 15:49:00'),(3,25,4,'FOLLOW_UP','2025-05-02 10:09:34'),(4,25,4,'in progress','2025-05-02 10:11:28'),(9,23,12,'assign','2025-05-14 17:58:41'),(17,13,12,'assign','2025-05-15 17:35:09'),(18,30,12,'assign','2025-05-15 17:48:33'),(19,27,12,'assign','2025-05-15 17:51:27'),(20,3,12,'follow up','2025-05-15 18:05:21'),(21,23,12,'follow up','2025-05-16 09:15:07'),(22,31,16,'assign','2025-05-16 11:04:38'),(24,22,21,'assign','2025-05-19 10:28:07'),(25,25,20,'assign','2025-05-19 10:28:48'),(26,25,20,'assign','2025-05-19 17:24:53'),(27,26,20,'assign','2025-05-19 17:26:31'),(28,24,21,'asss','2025-05-19 17:40:20'),(29,26,20,'allow','2025-05-19 17:42:04'),(30,5,22,'assign','2025-05-20 09:16:08'),(31,40,20,'pending','2025-05-22 11:14:24'),(32,72,6,'assign','2025-05-26 11:48:07');
/*!40000 ALTER TABLE `lead_status_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-06  9:09:06
