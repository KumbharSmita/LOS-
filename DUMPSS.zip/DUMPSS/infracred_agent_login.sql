-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: infracred
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agent_login`
--

DROP TABLE IF EXISTS `agent_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_login` (
  `agent_login_id` int unsigned NOT NULL AUTO_INCREMENT,
  `agent_registration_id` int unsigned DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`agent_login_id`),
  KEY `agent_registration_id` (`agent_registration_id`),
  CONSTRAINT `agent_login_ibfk_1` FOREIGN KEY (`agent_registration_id`) REFERENCES `agent_registration` (`agent_registration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_login`
--

LOCK TABLES `agent_login` WRITE;
/*!40000 ALTER TABLE `agent_login` DISABLE KEYS */;
INSERT INTO `agent_login` VALUES (1,NULL,'wajeakanksha@gmail.com','$2a$10$dXXyh85q/ml5abuox/QM.eA0g5cKv5290kR5kBTcWjvDLXUlMf0qi'),(2,3,'nisha@gmail.com','12345678'),(3,4,'nisha@gmail.com','12345678'),(4,5,'disha@gmail.com','82345678'),(5,6,'shakti@@gmail.com','98999796'),(6,7,'riya@gmail.com','77777777'),(7,8,'siya@gmail.com','66666666'),(8,9,'rutu@gmail.com','11111111'),(9,10,'123@gmail.com','11111111'),(10,11,'wajeakanksha@gmail.com','123456789'),(11,12,'sanu@gmail.com','99999999'),(12,13,'anjali@gmail.com','77755545'),(13,14,'anisha@gmail.com','anisha123'),(14,15,'manisha12@gmail.com','1211332323'),(15,16,'dfcksj@gmail.com','37657836538'),(16,17,'dfdfl12@gmail.com','dcfdsfcl1213'),(17,18,'gfdfg23@gmail.com','1235435'),(18,19,'dabi12@gmail.com','4375638783'),(19,20,'fadnvis12@gmail.com','3478637'),(20,21,'yogi123@gmail.com','yogi1234'),(21,22,'pankaja23@gmail.com','pankaja123'),(22,23,'raksha12@gmail.com','raksha1234'),(23,24,'aditi122@gmail.com','aditi1234'),(24,25,'amol123@gmail.com','amol1234'),(25,26,'chagan12@gmail.com','chagan1234'),(26,27,'isha12@gmail.com','isha1234'),(27,28,'hanumant455@gmail.com','8364375647'),(28,29,'simran34@gmail.com','dsjkhsdff'),(29,30,'sharada12@gmail.com','adklasjdsjfk'),(30,31,'tarak12@gmail.com','tarak8238'),(31,32,'madhavi2@gmail.com','akdlwdlfef'),(32,33,'dalal12@gmail.com','7845hedfk'),(33,34,'natasha2@gmail.com','ureiofejf'),(34,35,'tanushka4@gmail.com','djkskljf'),(35,36,'swastik4@gmail.com','fhejhirt'),(36,37,'alpana12@gmail.com','fgrgtrtr'),(37,38,'rupa12@gmail.com','dkjfskjd'),(38,39,'anant@gmail.com','hedfjehf');
/*!40000 ALTER TABLE `agent_login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-06  9:09:05
